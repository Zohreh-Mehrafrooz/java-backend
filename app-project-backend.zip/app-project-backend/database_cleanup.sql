drop table school_address;
drop table school_details;
drop table school_organization_mapping;
drop table organization;
drop table school;
