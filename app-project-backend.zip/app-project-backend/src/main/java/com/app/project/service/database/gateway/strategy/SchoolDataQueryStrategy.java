package com.app.project.service.database.gateway.strategy;

public interface SchoolDataQueryStrategy {

    String getAll();

    String getAll(String phonePrefix);

}
