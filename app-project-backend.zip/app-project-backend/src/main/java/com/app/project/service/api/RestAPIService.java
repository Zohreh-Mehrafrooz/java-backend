package com.app.project.service.api;

public abstract class RestAPIService {

    public abstract String get(String url);

}
