package com.app.project.model;

public class SchoolDetails {
    private int id;
    private int schoolId;
    private boolean hasPreKindergarten;
    private boolean hasKindergarten;
    private boolean hasGrade1;
    private boolean hasGrade2;
    private boolean hasGrade3;
    private boolean hasGrade4;
    private boolean hasGrade5;
    private boolean hasGrade6;
    private boolean hasGrade7;
    private boolean hasGrade8;
    private boolean hasGrade9;
    private boolean hasGrade10;
    private boolean hasGrade11;
    private boolean hasGrade12;

    public SchoolDetails() {
    }

    public SchoolDetails(int id, int schoolId, boolean hasPreKindergarten, boolean hasKindergarten, boolean hasGrade1, boolean hasGrade2, boolean hasGrade3, boolean hasGrade4, boolean hasGrade5, boolean hasGrade6, boolean hasGrade7, boolean hasGrade8, boolean hasGrade9, boolean hasGrade10, boolean hasGrade11, boolean hasGrade12) {
        this.id = id;
        this.schoolId = schoolId;
        this.hasPreKindergarten = hasPreKindergarten;
        this.hasKindergarten = hasKindergarten;
        this.hasGrade1 = hasGrade1;
        this.hasGrade2 = hasGrade2;
        this.hasGrade3 = hasGrade3;
        this.hasGrade4 = hasGrade4;
        this.hasGrade5 = hasGrade5;
        this.hasGrade6 = hasGrade6;
        this.hasGrade7 = hasGrade7;
        this.hasGrade8 = hasGrade8;
        this.hasGrade9 = hasGrade9;
        this.hasGrade10 = hasGrade10;
        this.hasGrade11 = hasGrade11;
        this.hasGrade12 = hasGrade12;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(int schoolId) {
        this.schoolId = schoolId;
    }

    public boolean getHasPreKindergarten() {
        return hasPreKindergarten;
    }

    public void setHasPreKindergarten(boolean hasPreKindergarten) {
        this.hasPreKindergarten = hasPreKindergarten;
    }

    public boolean getHasKindergarten() {
        return hasKindergarten;
    }

    public void setHasKindergarten(boolean hasKindergarten) {
        this.hasKindergarten = hasKindergarten;
    }

    public boolean getHasGrade1() {
        return hasGrade1;
    }

    public void setHasGrade1(boolean hasGrade1) {
        this.hasGrade1 = hasGrade1;
    }

    public boolean getHasGrade2() {
        return hasGrade2;
    }

    public void setHasGrade2(boolean hasGrade2) {
        this.hasGrade2 = hasGrade2;
    }

    public boolean getHasGrade3() {
        return hasGrade3;
    }

    public void setHasGrade3(boolean hasGrade3) {
        this.hasGrade3 = hasGrade3;
    }

    public boolean getHasGrade4() {
        return hasGrade4;
    }

    public void setHasGrade4(boolean hasGrade4) {
        this.hasGrade4 = hasGrade4;
    }

    public boolean getHasGrade5() {
        return hasGrade5;
    }

    public void setHasGrade5(boolean hasGrade5) {
        this.hasGrade5 = hasGrade5;
    }

    public boolean getHasGrade6() {
        return hasGrade6;
    }

    public void setHasGrade6(boolean hasGrade6) {
        this.hasGrade6 = hasGrade6;
    }

    public boolean getHasGrade7() {
        return hasGrade7;
    }

    public void setHasGrade7(boolean hasGrade7) {
        this.hasGrade7 = hasGrade7;
    }

    public boolean getHasGrade8() {
        return hasGrade8;
    }

    public void setHasGrade8(boolean hasGrade8) {
        this.hasGrade8 = hasGrade8;
    }

    public boolean getHasGrade9() {
        return hasGrade9;
    }

    public void setHasGrade9(boolean hasGrade9) {
        this.hasGrade9 = hasGrade9;
    }

    public boolean getHasGrade10() {
        return hasGrade10;
    }

    public void setHasGrade10(boolean hasGrade10) {
        this.hasGrade10 = hasGrade10;
    }

    public boolean getHasGrade11() {
        return hasGrade11;
    }

    public void setHasGrade11(boolean hasGrade11) {
        this.hasGrade11 = hasGrade11;
    }

    public boolean getHasGrade12() {
        return hasGrade12;
    }

    public void setHasGrade12(boolean hasGrade12) {
        this.hasGrade12 = hasGrade12;
    }
}
