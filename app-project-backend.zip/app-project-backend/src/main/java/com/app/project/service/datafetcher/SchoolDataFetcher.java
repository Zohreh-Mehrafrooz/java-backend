package com.app.project.service.datafetcher;

import com.app.project.model.SchoolAPIData;

import java.util.List;

public interface SchoolDataFetcher {

    List<SchoolAPIData> getSchoolData();

}
